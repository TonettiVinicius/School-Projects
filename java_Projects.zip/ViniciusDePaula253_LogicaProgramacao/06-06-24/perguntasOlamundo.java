import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;

// Vinicius de Paula Tonetti Costa e Theylor
//Turma 253

public class perguntasOlamundo {
   private static final String FILE_PATH = "cadastro.txt";

   public static void main(String[] args) {
      while (true) {
         // Pergunta 1
         String nome = JOptionPane.showInputDialog(null,
               "Digite o seu nome: ",
               "Cadastro",
               JOptionPane.PLAIN_MESSAGE);
         if (nome == null || nome.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Digite o seu nome: ",
                  "Cadastro", JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 2
         String sobrenome = JOptionPane.showInputDialog(null,
               "Digite seu sobrenome",
               "Cadastro", JOptionPane.PLAIN_MESSAGE);
         if (sobrenome == null || sobrenome.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Não pode ser vazio!",
                  "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 3
         String[] opcoesSexo = { "Masculino", "Feminino" };
         String sexo = (String) JOptionPane.showInputDialog(null,
               "Informe seu sexo:",
               "Cadastro",
               JOptionPane.PLAIN_MESSAGE, null, opcoesSexo, opcoesSexo[0]);
         if (sexo == null) {
            JOptionPane.showMessageDialog(null,
                  "Não pode estar vazio",
                  "Erro",
                  JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 4
         String endereco = JOptionPane.showInputDialog(null,
               "Digite seu endereço:",
               "Endereço", JOptionPane.PLAIN_MESSAGE);
         if (endereco == null || endereco.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Poh mano, o endereço não pode ser vazio!",
                  "erro, faz de novo", JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 5
         String cpf = JOptionPane.showInputDialog(null,
               "Digite seu CPF: ",
               "CPF", JOptionPane.PLAIN_MESSAGE);
         if (cpf == null || cpf.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Seu CPF não pode ser vazio!",
                  "erro, faz de novo", JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 6
         String idade = JOptionPane.showInputDialog(null,
               "Digite sua idade:",
               "Idade", JOptionPane.PLAIN_MESSAGE);
         if (endereco == null || endereco.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Digite sua idade novamente",
                  "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 7
         String[] opcoesIda = { "Nether", "Aether", "Inferno de Dante"};
         String ida = (String) JOptionPane.showInputDialog(null,
               "Para onde você vai dps q morrer?:",
               "Ida",
               JOptionPane.PLAIN_MESSAGE, null, opcoesIda, opcoesIda[0]);
         if (ida == null) {
            JOptionPane.showMessageDialog(null,
                  "Você tem que selecionar",
                  "Erro",
                  JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 8
         String escola = JOptionPane.showInputDialog(null,
               "Digite o nome da sua escola:",
               "Escola", JOptionPane.PLAIN_MESSAGE);
         if (escola == null || escola.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Não pode ser vazio!",
                  "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 9
         String jogo = JOptionPane.showInputDialog(null,
               "Qual o seu jogo favorito?:",
               "Jogo", JOptionPane.PLAIN_MESSAGE);
         if (jogo == null || jogo.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Não pode ser vazio!",
                  "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
         } // Pergunta 10
         String time = JOptionPane.showInputDialog(null,
               "Qual o seu time do coração?:",
               "Time", JOptionPane.PLAIN_MESSAGE);
         if (time == null || time.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                  "Não pode ser vazio!",
                  "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
            }  //Pergunta 11
            String partida = JOptionPane.showInputDialog(null,
               "Qual a sua partida favorita da Champions?",
               "Partida da champions", JOptionPane.PLAIN_MESSAGE);
            if (partida == null || partida.trim().isEmpty()) {
                  JOptionPane.showMessageDialog(null,
                  "Não pode ser vazio!",
                  "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
         } //pergunta 12
         String[] opcoesGOTY = { "RDR2", "GOW RAGNAROK", "Spiderman"};
         String goty = (String) JOptionPane.showInputDialog(null,
               "Qual era o jogo que merecia ganhar o GOTY de 2018?:",
               "  GOTY 2O18",
               JOptionPane.PLAIN_MESSAGE, null, opcoesGOTY, opcoesGOTY[0]);
         if (goty == null || goty != "RDR2") {
            JOptionPane.showMessageDialog(null,
                  "Só existe uma resposta correta, e não pode ser vazio!",
                  "Erro",
                  JOptionPane.ERROR_MESSAGE);
            continue;
         }
         //pergunta 13
         String[] opcoesGOTY2013 = { "GTA V", "TLOU", "BIOSHOCK"};
         String goty2013 = (String) JOptionPane.showInputDialog(null,
               "Qual era o jogo que merecia ganhar o GOTY de 2013?:",
               "GOTY 2013",
               JOptionPane.PLAIN_MESSAGE, null, opcoesGOTY2013, opcoesGOTY2013[0]);
         if (goty2013 == null || goty2013 != "GTA V") {
            JOptionPane.showMessageDialog(null,
                  "Só existe uma resposta correta, e não pode ser vazio!",
                  "Erro",
                  JOptionPane.ERROR_MESSAGE);
            continue;
         }
      //pergunta 14
      String[] maiorTime = { "Criciúma", "Avaí", "Figueirense", "Chapecoense"};
      String timeSC = (String) JOptionPane.showInputDialog(null,
            "Qual é o maior time de Santa Cantarina?:",
            "Maior TIme",
            JOptionPane.PLAIN_MESSAGE, null, maiorTime, maiorTime[0]);
      if (timeSC == null || timeSC != "Criciúma") {
         JOptionPane.showMessageDialog(null,
               "Só existe uma resposta correta, e não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue; 
      }
      //pergunta 15
      String[] melhorPromessa = { "Qualquer promessa do Real", "Lamine Yamal", "Gavi", "Pedri"};
      String promessa = (String) JOptionPane.showInputDialog(null,
            "Qual é a melhor promessa?:",
            "Melhor Promessa",
            JOptionPane.PLAIN_MESSAGE, null, melhorPromessa, melhorPromessa[0]);
      if (promessa == null || promessa != "Qualquer promessa do Real") {
         JOptionPane.showMessageDialog(null,
               "Só existe uma resposta correta, e não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue;
      }
      //pergunta 16
      String[] melhorComida = { "Estrogonofe", "Lasanha", "Carne", "Queijo"};
      String comida = (String) JOptionPane.showInputDialog(null,
            "Qual é a melhor comida?:",
            "Melhor Comida",
            JOptionPane.PLAIN_MESSAGE, null, melhorComida, melhorComida[0]);
      if (comida == null) {
         JOptionPane.showMessageDialog(null,
               "Não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue;
      }
      //pergunta 16
      String[] amorVida = { "Relógio", "Alicia", "Lili", "Irmã da Bibi"};
      String amor = (String) JOptionPane.showInputDialog(null,
            "Quem é o amor da minha vida?:",
            "Amor da vida",
            JOptionPane.PLAIN_MESSAGE, null, amorVida, amorVida[0]);
      if (amor == null) {
         JOptionPane.showMessageDialog(null,
               "Não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue;
      }
      //pergunta 17
      String[] melhorAsa = { "Light", "Icy", "Fire", "Wind"};
      String asas = (String) JOptionPane.showInputDialog(null,
            "Qual é o melhor Asa?",
            "Asas",
            JOptionPane.PLAIN_MESSAGE, null, melhorAsa, melhorAsa[0]);
      if (asas == null) {
         JOptionPane.showMessageDialog(null,
               "Não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue;
      }
      //pergunta 18
      String[] melhorTenis = { "Electric", "Leonardo", "Sieglitz", "Eduardo Baixinho"};
      String tenisDeMesa = (String) JOptionPane.showInputDialog(null,
            "Qual é o melhor jogador de tênis de mesa da escola?",
            "Tenis de mesa",
            JOptionPane.PLAIN_MESSAGE, null, melhorTenis, melhorTenis[0]);
      if (tenisDeMesa == null) {
         JOptionPane.showMessageDialog(null,
               "Não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue;
      }
      //pergunta 19
      String[] melhorJogador = { "Electric", "Samuel da Luz", "Kaua", "Joaquim"};
      String futebol253 = (String) JOptionPane.showInputDialog(null,
            "Qual é o melhor jogador de futebol da sala?",
            "Futebol",
            JOptionPane.PLAIN_MESSAGE, null, melhorJogador, melhorJogador[0]);
      if (futebol253 == null) {
         JOptionPane.showMessageDialog(null,
               "Não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue;
      }
      //pergunta 20
      String[] maisInteligente = { "Electric", "Tonetti", "Redx", "Vinicius de Paula"};
      String vinicius = (String) JOptionPane.showInputDialog(null,
            "Qual é a minha versão mais inteligente?",
            "Versões",
            JOptionPane.PLAIN_MESSAGE, null, maisInteligente, maisInteligente[0]);
      if (vinicius == null) {
         JOptionPane.showMessageDialog(null,
               "Não pode ser vazio!",
               "Erro",
               JOptionPane.ERROR_MESSAGE);
         continue;
      }
      salvarCadastro(
               nome,
               sobrenome,
               sexo,
               endereco,
               cpf,
               idade,
               ida,
               escola,
               jogo,
               time, partida, goty, goty2013, timeSC, promessa, comida, amor, asas, tenisDeMesa, futebol253, vinicius);
         int resposta = JOptionPane.showConfirmDialog(null,
               "Deseja cadastrar outra pesssoa ?",
               "Continuar",
               JOptionPane.YES_NO_CANCEL_OPTION);
         if (resposta == JOptionPane.NO_OPTION) {
            break;

         }
      }
   }

   public static void salvarCadastro(
         String nome,
         String sobrenome,
         String sexo,
         String endereco,
         String cpf,
         String idade,
         String ida,
         String escola,
         String jogo,
         String time,
         String partida,
         String goty,
         String goty2013,
         String timeSC,
         String promessa,
         String comida,
         String amor,
         String asas, 
         String tenisDeMesa,
         String futebol253,
         String vinicius
         ) {
      try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH,
            true))) {
         writer.write(
            nome + ", " + sobrenome + ", " + sexo + ", " + endereco + ", "+ cpf + ", " + idade + ", " + ida + ", " + escola + ", " + jogo + ", " + time + ", " + partida + ", " + goty + ", " + goty2013 + ", " + timeSC + ", " + promessa + ", " + comida + ", " + amor + ", " + asas + ", " + tenisDeMesa + ", " + futebol253 + ", " + vinicius + "."  
                     );
         writer.newLine();
         JOptionPane.showMessageDialog(null,
               "Cadastro realizado com sucesso!",
               "Sucesso", JOptionPane.INFORMATION_MESSAGE);
      } catch (IOException e) {
         JOptionPane.showMessageDialog(null,
               "Erro ao salvar os dados",
               "Erro", JOptionPane.ERROR_MESSAGE);

      }
   }

}