//Vinicius de Paula e Theylor 
//turma:253


public class hello_word {

    public static void main(String[] args) {
        
        //demonstra amenssagem para o usuario
        System.out.println("hello world");



    }








}