import javax.swing.JOptionPane;

//Vinicius de Paula e Theylor 253

public class popup{
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Olá, Mundo!");
    }
}