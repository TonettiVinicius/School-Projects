import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;

//Vinicius de Paula e Theylor 253 

public  class cadastroLacoRep {
    private static final String FILE_PATH = "cadastros.txt";
    
    public static void main(String[] args) {
        while (true) { 
        String nome = JOptionPane.showInputDialog(null, "Digite o nome: ", "Cadastro de Usuário", JOptionPane.PLAIN_MESSAGE);
        if(nome == null || nome.trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Nome não pode ser vazio!", "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        String sobrenome = JOptionPane.showInputDialog(null, "Digite o sobrenome: ", "Cadastro de Usuário", JOptionPane.PLAIN_MESSAGE);
        if(sobrenome == null || nome.trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Sobrenome não pode ser vazio!", "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        String[] opcoesSexo = {"Masculino", "Feminino"};
        String sexo = (String)  JOptionPane.showInputDialog(null, "Selecione o sexo: ", "Cadastro de Usuário", JOptionPane.PLAIN_MESSAGE, null, opcoesSexo, opcoesSexo[0]);
        if(sexo == null || nome.trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Sexo deve ser selecionado!", "Erro", JOptionPane.ERROR_MESSAGE);
            continue;
        }
            salvarCadastro(nome, sobrenome, sexo);
            int resposta = JOptionPane.showConfirmDialog(null, "Deseja cadastrar outra pessoa?", "Continuar", JOptionPane.YES_NO_OPTION);
            if (resposta == JOptionPane.NO_OPTION) {
                break;
            }
        }
    }
    private static void  salvarCadastro(String nome, String sobrenome, String sexo){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            writer.write(nome + "," + sobrenome + "," + sexo);
            writer.newLine();
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);            
        } catch(IOException e){
            JOptionPane.showMessageDialog(null, "Erro ao salvar os dados!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}