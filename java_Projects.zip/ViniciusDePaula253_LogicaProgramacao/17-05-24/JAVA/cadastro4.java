import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;
/*nome Vinicius de Paula Tonetti
Turma: 253
*/
public class cadastro {
    public static void main(String[] args) {
        Scanner scanner =  new Scanner(System.in);

        System.out.println("Digite seu nome: ");
        String nome = scanner.nextLine();
        
        System.out.println("Digite seu sobrenome: ");
        String sobrenome = scanner.nextLine();

        System.out.println("Digite a data de nascimento no formato AAAA-MM-DD: ");
        String dataNascStr = scanner.nextLine();

        LocalDate dataNasc = LocalDate.parse(dataNascStr);

        LocalDate dataAtual = LocalDate.now();
        Period periodo = Period.between(dataNasc, dataAtual);
        int idade = periodo.getYears(); 

        System.out.println("Digite seu CPF: ");
        int cpf = scanner.nextInt();

        System.out.println("Digite o seu endereço: ");
        String endereco = scanner.nextLine();
        
        System.out.println("Digite o seu salário: ");
        float salario = scanner.nextFloat();

        System.out.println("Digite seu RG: ");
        String rg = scanner.nextLine();

        System.out.println("Digite 'M' para masculino ou 'F' para feminino: ");
        char sexo = scanner.nextLine().charAt(0);

        String genero = "";

        if (sexo == 'M' || sexo == 'm') 
        {
            genero = "Masculino";    
        } else if (sexo == 'F' || sexo == 'f') {
            genero = "Feminino";
        } else{
            genero = "Indefinido";
        }

        System.out.println("Nome: " + nome);
        System.out.println("Sobrenome: " + sobrenome); 
        System.out.println("Idade: " + idade + " anos.");
        System.out.println("Genero: " + genero);
        System.out.println("Endereço: " + endereco);
        System.out.println("CPF: " + cpf);
        System.out.println("RG: " + rg);
        System.out.println("Salário: " + salario);
        scanner.close();


    }
}