import java.util.Scanner;
/*nome Vinicius de Paula Tonetti
Turma: 253
*/
public class cadastro {
    public static void main(String[] args) {
        Scanner scanner =  new Scanner(System.in);

        System.out.println("Digite seu nome: ");
        String nome = scanner.nextLine();
        
        System.out.println("Digite seu sobrenome: ");
        String sobrenome = scanner.nextLine();
        
        System.out.println("Digite 'M' para masculino ou 'F' para feminino: ");
        char sexo = scanner.nextLine().charAt(0);

        String genero = "";

        if (sexo == 'M' || sexo == 'm') 
        {
            genero = "Masculino";    
        } else if (sexo == 'F' || sexo == 'f') {
            genero = "Feminino";
        } else{
            genero = "Indefinido";
        }

        System.out.println("Nome: " + nome);
        System.out.println("Sobrenome: " + sobrenome);
        System.out.println("Genero: " + genero);
        scanner.close();
    }
}